// models/Seance.js
const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Seance = sequelize.define("Seance", {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    clientCin: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    clientNom: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dateSeance: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    typeSeance: {
      type: DataTypes.ENUM("Code", "Conduit", "Parc"),
      allowNull: false,
      defaultValue: "Code",
    },
    fraisPaye: {
      type: DataTypes.ENUM("Payée", "Non Payée"),
      allowNull: false,
      defaultValue: "Non Payée",
    },
    coutSeance: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      defaultValue: 0.0,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  });

  return Seance;
};