// routes/seances.js
const { setupDatabase } = require("../models/index");

async function handleSeances(event) {
  console.log("Starting handleSeances");
  const { pathParameters, body } = event;
  const httpMethod = event?.requestContext?.http?.method;
  const { Seance, Client } = await setupDatabase();

  if (!httpMethod) {
    console.log("No HTTP method provided in event:", JSON.stringify(event));
    return { statusCode: 400, body: JSON.stringify({ error: "Méthode HTTP requise" }) };
  }

  try {
    const requestBody = body ? JSON.parse(body) : {};

    switch (httpMethod.toUpperCase()) {
      case "GET":
        if (pathParameters && pathParameters.id) {
          console.log(`Fetching seance with ID: ${pathParameters.id}`);
          const seance = await Seance.findByPk(pathParameters.id, {
            include: { model: Client, as: "client" },
          });
          if (!seance) {
            console.log("Seance not found");
            return { statusCode: 404, body: JSON.stringify({ error: "Séance non trouvée" }) };
          }
          console.log("Seance retrieved successfully");
          return { statusCode: 200, body: JSON.stringify(seance) };
        } else {
          console.log("Fetching all seances");
          const seances = await Seance.findAll({
            include: { model: Client, as: "client" },
          });
          console.log(`Retrieved ${seances.length} seances`);
          return { statusCode: 200, body: JSON.stringify(seances) };
        }

      case "POST":
        console.log("Creating new seance");
        const { clientCin } = requestBody;
        if (!clientCin) {
          console.log("clientCin is required");
          return { statusCode: 400, body: JSON.stringify({ error: "Le champ clientCin est requis" }) };
        }
        const client = await Client.findOne({ where: { cin: clientCin } });
        if (!client) {
          console.log("Client not found for seance");
          return { statusCode: 400, body: JSON.stringify({ error: "Client introuvable" }) };
        }
        const newSeance = await Seance.create(requestBody);
        console.log("Seance created successfully");
        return { statusCode: 201, body: JSON.stringify(newSeance) };

      case "PUT":
        if (!pathParameters || !pathParameters.id) {
          console.log("ID required in URL");
          return { statusCode: 400, body: JSON.stringify({ error: "ID requis dans l'URL" }) };
        }
        console.log(`Updating seance with ID: ${pathParameters.id}`);
        const [updated] = await Seance.update(requestBody, {
          where: { id: pathParameters.id },
          returning: true,
        });
        if (!updated) {
          console.log("Seance not found for update");
          return { statusCode: 404, body: JSON.stringify({ error: "Séance non trouvée" }) };
        }
        const updatedSeance = await Seance.findByPk(pathParameters.id);
        console.log("Seance updated successfully");
        return { statusCode: 200, body: JSON.stringify({ message: "Séance mise à jour avec succès", seance: updatedSeance }) };

      case "DELETE":
        if (!pathParameters || !pathParameters.id) {
          console.log("ID required in URL");
          return { statusCode: 400, body: JSON.stringify({ error: "ID requis dans l'URL" }) };
        }
        console.log(`Deleting seance with ID: ${pathParameters.id}`);
        const deleted = await Seance.destroy({ where: { id: pathParameters.id } });
        if (!deleted) {
          console.log("Seance not found for deletion");
          return { statusCode: 404, body: JSON.stringify({ error: "Séance non trouvée" }) };
        }
        console.log("Seance deleted successfully");
        return { statusCode: 200, body: JSON.stringify({ message: "Séance supprimée avec succès" }) };

      default:
        console.log("Method not allowed:", httpMethod);
        return { statusCode: 405, body: JSON.stringify({ error: "Méthode non autorisée" }) };
    }
  } catch (error) {
    console.error("Error in seances handler:", error.message);
    return { statusCode: 500, body: JSON.stringify({ error: "Erreur lors du traitement de la requête seances", details: error.message }) };
  }
}

module.exports = { handleSeances };